#include <iostream>
#include <string>

using namespace std;
int main() {
    string name = "Braden";
    int age = 27;
    float weight = 161.5;
    cout << "Name: " << name << endl;
    cout << "Age: " << age << endl;
    cout << "Weight: " << weight << endl;
    return 0;
}
